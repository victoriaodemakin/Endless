<?php

namespace PlazartInstallation\Toolbar;

defined( 'ABSPATH' ) || exit;

if(!class_exists('PlazartInstallation\Toolbar\Toolbar')){
    class Toolbar{

    }
}