tinyMCE.addI18n({en_US:{
cookieJar:{
desc : 'Drop an Affiliate Cookie'
}}});