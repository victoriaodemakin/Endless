<?php

//require_once PLUGIN_SERVER_PATH.'/admin/post-type/function-init.php';
require_once PLUGIN_SERVER_PATH.'/admin/vc-extension/vc-init.php';
require_once PLUGIN_SERVER_PATH.'/admin/shortcode/function_shortcode.php';
/*
    * Required: widget social
    */
require PLUGIN_SERVER_PATH . '/admin/widgets/social.php';

/*
    * Required: widget contact
    */
require PLUGIN_SERVER_PATH . '/admin/widgets/contact-info.php';

/*
        * Required: widget post
        */
require PLUGIN_SERVER_PATH . '/admin/widgets/view-post.php';

?>