/* Add socials */

jQuery(document).ready(function(){
    var $click = true;
    jQuery('.socials-header').on('click',function(){
        if ( $click == true ) {
            jQuery(this).next().slideDown(250);
            jQuery(this).css('background-position','100% 15px');
            $click = false;
        }else{
            jQuery(this).next().slideUp(300);
            jQuery(this).css('background-position','100% -20px');
            $click = true;
        }
    });


    jQuery('.tzsocials_button').on('click',function(){

        var $parent = jQuery(this).prev();
        var $count = $parent.find('li:last').attr('rel');
        var $count2 = parseInt($count) + 1;
        var social_none = jQuery(this).parents('.widget-content').find('.social_none').val();
        jQuery.ajax({
            url: svl_array.admin_ajax,
            type: "POST",
            data: ({ action:'add_socials', security: social_none,count:$count2 }),
            beforeSend: function() {

            },
            success: function( data, textStatus, jqXHR ){
                var $ajax_response = jQuery( data );
                $parent.append($ajax_response);
            },
            error: function( jqXHR, textStatus, errorThrown ){

            },
            complete: function( jqXHR, textStatus ){
            }
        });
    });

    jQuery('.tzsocial_remove').on('click',function(){
        jQuery(this).parent().parent().remove();
    });
    jQuery('.tzsocialsp_remove').on('click',function(){
        jQuery(this).parent().parent().remove();
    })
});
