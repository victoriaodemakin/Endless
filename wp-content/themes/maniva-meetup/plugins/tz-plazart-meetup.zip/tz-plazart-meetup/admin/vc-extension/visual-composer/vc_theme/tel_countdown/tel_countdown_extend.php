<?php
if (!defined('ABSPATH')) {
    exit;
}
vc_map(array(
    'name' => esc_html__('Count Down', 'plazart-plugin'),
    'base' => 'tel_countdown',
    'class' => 'tel-countdown',
    "icon" => "icon-element",
    'show_settings_on_create' => true,
    'category' => esc_html__('Maniva Meetup', 'plazart-plugin'),
    'params' => array(
        array(
            "type" => "textfield",
            "class" => "",
            "heading" => esc_html__("Sub Title", "tz-plazart"),
            "param_name" => "tz_sub_title",
            "value" => "",

        ),
        array(
            "type" => "textfield",
            "class" => "",
            "heading" => esc_html__("Title", "tz-plazart"),
            "param_name" => "tz_title",
            "value" => "",

        ),

        // Timer coundown setting

        // Year
        array(
            'type' => 'textfield',
            'class' => '',
            'admin_label' => false,
            'heading' => esc_html__('Year', 'plazart-plugin'),
            'param_name' => 'tel_countdown_year',
            'description' => esc_html__('Eg: 2020', 'plazart-plugin'),
            "value" => '2020',

        ),
        // Month
        array(
            'type' => 'dropdown',
            'class' => '',
            'admin_label' => false,
            'heading' => esc_html__('Month', 'plazart-plugin'),
            'param_name' => 'tel_countdown_month',
            'description' => esc_html__('', 'plazart-plugin'),

            "value" => array(
                "January" => "Jan",
                "February" => "Feb",
                "March" => "Mar",
                "April" => "Apr",
                "May" => "May",
                "June" => "Jun",
                "July" => "Jul",
                "August" => "Aug",
                "September" => "Sep",
                "October" => "Oct",
                "November" => "Nov",
                "December" => "Dec"
            )

        ),
        // Day
        array(
            'type' => 'textfield',
            'class' => '',
            'admin_label' => false,
            'heading' => esc_html__('Day', 'plazart-plugin'),
            'param_name' => 'tel_countdown_day',
            'description' => esc_html__('Max: 31', 'plazart-plugin'),
            "value" => '1',

        ),
        // Hour
        array(
            'type' => 'textfield',
            'class' => '',
            'admin_label' => false,
            'heading' => esc_html__('Hour', 'plazart-plugin'),
            'param_name' => 'tel_countdown_hour',
            'description' => esc_html__('Max: 24', 'plazart-plugin'),
            "value" => '1',

        ),
        // Minute
        array(
            'type' => 'textfield',
            'class' => '',
            'admin_label' => false,
            'heading' => esc_html__('Minute', 'plazart-plugin'),
            'param_name' => 'tel_countdown_minute',
            'description' => esc_html__('Max: 60', 'plazart-plugin'),
            "value" => '1',

        ),
        // Second
        array(
            'type' => 'textfield',
            'class' => '',
            'admin_label' => false,
            'heading' => esc_html__('Second', 'plazart-plugin'),
            'param_name' => 'tel_countdown_second',
            'description' => esc_html__('Max: 60', 'plazart-plugin'),
            "value" => '1',

        ),
        array(
            "type"          =>  "colorpicker",
            "class"         =>  "hide_in_vc_editor",
            "heading"       => "Choose font Color",
            "param_name"    => "color_title",
            "description"   => "Choose color of title"
        ),
        // Animation, ID, Class
        vc_map_add_css_animation(),
        array(
            'type' => 'el_id',
            'heading' => esc_html__('Element ID', 'plazart-plugin'),
            'param_name' => 'tel_countdown_id',
            'description' => sprintf(__('Enter element ID (Note: make sure it is unique and valid according to <a href="%s" target="_blank">w3c specification</a>).', 'js_composer'), 'http://www.w3schools.com/tags/att_global_id.asp'),

        ),
        array(
            'type' => 'textfield',
            'heading' => esc_html__('Extra class name', 'plazart-plugin'),
            'param_name' => 'tel_countdown_class',
            'description' => esc_html__('Style particular content element differently - add a class name and refer to it in custom CSS.', 'plazart-plugin'),

        ),
        array(
            'type' => 'css_editor',
            'heading' => esc_html__('CSS box', 'tz-plazart'),
            'param_name' => 'css',
            'group' => esc_html__('Design Options', 'tz-plazart'),
        ),

    )
));