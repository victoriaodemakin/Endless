<?php

    $type = $title = $sub_title = $color_title = $color_sub_title = '';

extract( shortcode_atts( array(

    'title'             =>  '',
    'sub_title'         =>  '',
    'color_title'       =>  '',
    'color_sub_title'   =>  '',
    'type'   =>  '1',

), $atts ) );
    if (  $type == '1') {
        $event_class = 'tz_event_type1';
    } elseif (  $type == '2') {
        $event_class = 'tz_event_type2';
    }
?>

<div class="tz_event_meetup <?php echo esc_attr( $event_class); ?>">
    <div class="tz_box_event_meetup">
        <h3 <?php echo( $color_title != '' ? 'style="color:' . esc_attr( $color_title ) . '"' : '' ); ?>>
            <?php echo balanceTags( $title ); ?>
        </h3>
        <h3 class="tz_event_meetup_subtitle" <?php echo( $color_sub_title != '' ? 'style="color:' . esc_attr( $color_sub_title ) . '"' : '' ); ?>>
            <?php echo balanceTags( $sub_title ); ?>
        </h3>
        <div class="tz_event_meettup_box_content">
            <div class="tz_event_meetup_content">
                <?php echo do_shortcode( $content ); ?>
            </div>
        </div>
    </div>
</div>
